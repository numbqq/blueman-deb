class PluginException(Exception):
    pass


class UnsupportedPlatformError(PluginException):
    pass
