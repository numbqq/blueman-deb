from blueman.services.meta.NetworkService import NetworkService as NetworkService
from blueman.services.meta.SerialService import SerialService as SerialService

__all__ = ["NetworkService", "SerialService"]
